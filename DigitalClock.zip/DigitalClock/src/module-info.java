module DigitalClock {
    requires javafx.base;
    requires javafx.controls;

    opens sample to javafx.graphics;
}